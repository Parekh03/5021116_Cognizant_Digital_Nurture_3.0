public class Main {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("photo1.jpg");
        Image image2 = new ProxyImage("photo2.jpg");

        // Display images; image1 will be loaded from remote server
        System.out.println("Displaying image1 for the first time:");
        image1.display(); 
        System.out.println();

        // Display images again; image1 should not be loaded again
        System.out.println("Displaying image1 again:");
        image1.display();
        System.out.println();

        // Display image2; image2 will be loaded from remote server
        System.out.println("Displaying image2 for the first time:");
        image2.display();
    }
}
