package myPackage;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@NamedQueries({
        @NamedQuery(
                name = "Employee.findByDepartmentId",
                query = "SELECT e FROM Employee e WHERE e.department.id = :departmentId"
        ),
        @NamedQuery(
                name = "Employee.findByNameContaining",
                query = "SELECT e FROM Employee e WHERE e.name LIKE %:name%"
        )
})
@Table(name = "employees")
@Data
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String email;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id")
    private Department department;
}
