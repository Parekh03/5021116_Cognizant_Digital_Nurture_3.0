package Repository;

import myPackage.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Find all employees with pagination and sorting
    Page<Employee> findAll(Pageable pageable);

    // Find by department name with pagination and sorting
    Page<Employee> findByDepartmentName(String departmentName, Pageable pageable);

    // Find by email domain with pagination and sorting
    @Query("SELECT e FROM Employee e WHERE e.email LIKE %:domain%")
    Page<Employee> findEmployeesByEmailDomain(@Param("domain") String domain, Pageable pageable);
}