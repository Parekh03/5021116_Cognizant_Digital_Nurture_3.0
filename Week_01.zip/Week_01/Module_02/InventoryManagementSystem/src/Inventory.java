import java.util.HashMap;
public class Inventory {
    private HashMap<String, Product> products;

    public Inventory() {
        this.products = new HashMap<>();
    }

    public void addProduct(Product product) {
        if (products.containsKey(product.getProductId())) {
            System.out.println("Product with ID " + product.getProductId() + " already exists.");
        } else {
            products.put(product.getProductId(), product);
            System.out.println("Product " + product.getProductName() + " added successfully.");
        }
    }

    public void updateProduct(String productId, String newName, Integer newQuantity, Double newPrice) {
        Product product = products.get(productId);
        if (product != null) {
            if (newName != null) {
                product.setProductName(newName);
            }
            if (newQuantity != null) {
                product.setQuantity(newQuantity);
            }
            if (newPrice != null) {
                product.setPrice(newPrice);
            }
            System.out.println("Product with ID " + productId + " updated successfully.");
        } else {
            System.out.println("Product with ID " + productId + " does not exist.");
        }
    }

    public void deleteProduct(String productId) {
        if (products.containsKey(productId)) {
            products.remove(productId);
            System.out.println("Product with ID " + productId + " deleted successfully.");
        } else {
            System.out.println("Product with ID " + productId + " does not exist.");
        }
    }

    public Product getProduct(String productId) {
        return products.get(productId);
    }

    public void displayProducts() {
        if (products.isEmpty()) {
            System.out.println("No products in inventory.");
        } else {
            for (Product product : products.values()) {
                System.out.println(product);
            }
        }
    }
}
