// Main.java
public class Main {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        // Pay using Credit Card
        PaymentStrategy creditCard = new CreditCardPayment("1234-5678-9012-3456", "John Doe", "123", "12/25");
        context.setPaymentStrategy(creditCard);
        context.pay(100.00);

        // Pay using PayPal
        PaymentStrategy paypal = new PayPalPayment("john.doe@example.com", "password123");
        context.setPaymentStrategy(paypal);
        context.pay(200.00);
    }
}
