package com.example.BookstoreAPI.controller;

import com.example.BookstoreAPI.dto.BookDTO;
import com.example.BookstoreAPI.mapper.BookMapper;
import com.example.BookstoreAPI.model.Book;
import com.example.BookstoreAPI.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<EntityModel<BookDTO>> createBook(@RequestBody BookDTO bookDTO) {
        BookDTO createdBook = bookService.createBook(bookDTO);
        EntityModel<BookDTO> resource = EntityModel.of(createdBook);
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(BookController.class).getBookById(createdBook.getId())).withSelfRel());
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(BookController.class).getAllBooks()).withRel("books"));
        return new ResponseEntity<>(resource, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<BookDTO>> getBookById(@PathVariable int id) {
        BookDTO bookDTO = bookService.getBookById(id);
        EntityModel<BookDTO> resource = EntityModel.of(bookDTO);
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(BookController.class).getBookById(id)).withSelfRel());
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(BookController.class).getAllBooks()).withRel("books"));
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(BookController.class).updateBook(id, bookDTO)).withRel("update"));
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(BookController.class).deleteBook(id)).withRel("delete"));
        return new ResponseEntity<>(resource, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<BookDTO>>> getAllBooks() {
        List<EntityModel<BookDTO>> books = bookService.getAllBooks().stream()
                .map(bookDTO -> EntityModel.of(bookDTO,
                        WebMvcLinkBuilder.linkTo(methodOn(BookController.class).getBookById(bookDTO.getId())).withSelfRel(),
                        WebMvcLinkBuilder.linkTo(methodOn(BookController.class).getAllBooks()).withRel("books")))
                .collect(Collectors.toList());
        CollectionModel<EntityModel<BookDTO>> collectionModel = CollectionModel.of(books);
        collectionModel.add(WebMvcLinkBuilder.linkTo(methodOn(BookController.class).getAllBooks()).withSelfRel());
        return new ResponseEntity<>(collectionModel, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<BookDTO>> updateBook(@PathVariable int id, @RequestBody BookDTO bookDTO) {
        BookDTO updatedBook = bookService.updateBook(id, bookDTO);
        EntityModel<BookDTO> resource = EntityModel.of(updatedBook);
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(BookController.class).getBookById(updatedBook.getId())).withSelfRel());
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(BookController.class).getAllBooks()).withRel("books"));
        return new ResponseEntity<>(resource, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<Void> deleteBook(@PathVariable int id) {
        bookService.deleteBook(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/search")
    public ResponseEntity<CollectionModel<EntityModel<BookDTO>>> searchBooks(@RequestParam(required = false) String title,
                                                                             @RequestParam(required = false) String author) {
        List<EntityModel<BookDTO>> books = bookService.searchBooks(title, author).stream()
                .map(bookDTO -> EntityModel.of(bookDTO,
                        WebMvcLinkBuilder.linkTo(methodOn(BookController.class).getBookById(bookDTO.getId())).withSelfRel(),
                        WebMvcLinkBuilder.linkTo(methodOn(BookController.class).getAllBooks()).withRel("books")))
                .collect(Collectors.toList());
        CollectionModel<EntityModel<BookDTO>> collectionModel = CollectionModel.of(books);
        collectionModel.add(WebMvcLinkBuilder.linkTo(methodOn(BookController.class).getAllBooks()).withSelfRel());
        return new ResponseEntity<>(collectionModel, HttpStatus.OK);
    }

}
