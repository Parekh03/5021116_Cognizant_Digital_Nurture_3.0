public class MainOptimized {

    // Iterative method to calculate future value
    public static double futureValueIterative(double presentValue, double growthRate, int periods) {
        double futureValue = presentValue;
        for (int i = 0; i < periods; i++) {
            futureValue *= (1 + growthRate);
        }
        return futureValue;
    }

    public static void main(String[] args) {
        double presentValue = 1000.0;  // Example present value
        double growthRate = 0.05;      // Example growth rate (5%)
        int periods = 10;              // Example number of periods (10 years)

        double futureValue = futureValueIterative(presentValue, growthRate, periods);
        System.out.println("Future Value: " + futureValue);
    }
}
