public class Main {
    public static void main(String[] args) {
        // Create a new student
        Student student = new Student("John Doe", "1234", "A");

        // Create a view to display student details
        StudentView view = new StudentView();

        // Create a controller
        StudentController controller = new StudentController(student, view);

        // Display initial student details
        controller.updateView();

        // Update student details
        controller.setStudentName("Parekh Ved");
        controller.setStudentId("582");
        controller.setStudentGrade("A");

        // Display updated student details
        controller.updateView();
    }
}
