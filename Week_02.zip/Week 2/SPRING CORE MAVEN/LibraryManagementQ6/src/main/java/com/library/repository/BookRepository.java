package com.library.repository;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
    // List to store all the books in the repository
    private List<String> books = new ArrayList<>();

    public void printClass() {
        System.out.println("Inside the BookRepository class");
    }

    public void save(String book) {
        books.add(book);
    }

    public List<String> findAll() {
        return new ArrayList<>(books);
    }
}
