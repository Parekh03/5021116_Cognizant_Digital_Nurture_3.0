public class CustomerRepositoryImpl implements CustomerRepository {

    @Override
    public Customer findCustomerById(String id) {
        // For demonstration purposes, we are returning a hard-coded customer.
        // In a real application, this method would query a database.
        return new Customer(id, "Parekh Ved");
    }
}
