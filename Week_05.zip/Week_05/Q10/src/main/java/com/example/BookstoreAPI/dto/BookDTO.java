package com.example.BookstoreAPI.dto;

import org.springframework.hateoas.RepresentationModel;

public class BookDTO extends RepresentationModel<BookDTO> {
    private int id;
    private String title;
    private String author;
    private double price;
    private String isbn;
    private int version;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}