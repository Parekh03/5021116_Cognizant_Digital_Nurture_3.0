import java.util.Arrays;

public class Main {
    private Employee[] employees;
    private int size;

    public Main(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    // Add an employee
    public void addEmployee(Employee employee) {
        if (size >= employees.length) {
            employees = Arrays.copyOf(employees, employees.length * 2);
        }
        employees[size++] = employee;
    }

    // Search for an employee by employeeId
    public Employee searchEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    // Traverse and display all employees
    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // Delete an employee by employeeId
    public boolean deleteEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[--size] = null;
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        Main system = new Main(2);

        // Add employees
        system.addEmployee(new Employee("E001", "Alice", "Developer", 80000));
        system.addEmployee(new Employee("E002", "Bob", "Manager", 90000));
        system.addEmployee(new Employee("E003", "Charlie", "Analyst", 75000));

        // Traverse employees
        System.out.println("All Employees:");
        system.traverseEmployees();

        // Search for an employee
        String searchId = "E002";
        Employee searchResult = system.searchEmployee(searchId);
        System.out.println("\nSearch Result for Employee ID " + searchId + ":");
        System.out.println(searchResult != null ? searchResult : "Employee not found");

        // Delete an employee
        String deleteId = "E001";
        boolean deleteResult = system.deleteEmployee(deleteId);
        System.out.println("\nDelete Result for Employee ID " + deleteId + ": " + (deleteResult ? "Success" : "Employee not found"));

        // Traverse employees after deletion
        System.out.println("\nAll Employees after deletion:");
        system.traverseEmployees();
    }
}
