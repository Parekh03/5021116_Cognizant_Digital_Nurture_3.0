import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class SearchFunctions {

    // Linear Search
    public static Product linearSearch(Product[] products, String productName) {
        for (Product product : products) {
            if (product.getProductName().equals(productName)) {
                return product;
            }
        }
        return null;
    }

    // Binary Search (assumes the array is sorted by product name)
    public static Product binarySearch(Product[] products, String productName) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductName().compareTo(productName);

            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "Phone", "Electronics"),
            new Product("3", "Shirt", "Clothing"),
            new Product("4", "Pants", "Clothing"),
            new Product("5", "Headphones", "Electronics")
        };
        
        System.out.println("Products details:\n");
        
        for(Product p : products) {
        	System.out.println(p);
        }
        System.out.println();
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the name of the product you want to search : ");
        String searchProductName = sc.next();

        // Linear Search
        Product result = linearSearch(products, searchProductName);
        System.out.println("Linear Search Result: " + (result != null ? result : "Product not found"));

        // Sort the array for Binary Search
        Arrays.sort(products, Comparator.comparing(Product::getProductName));

        // Binary Search
        result = binarySearch(products, searchProductName);
        System.out.println("Binary Search Result: " + (result != null ? result : "Product not found"));
    }
}
