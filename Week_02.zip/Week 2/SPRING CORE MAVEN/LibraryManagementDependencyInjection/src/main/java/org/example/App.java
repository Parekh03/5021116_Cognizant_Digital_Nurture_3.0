package org.example;

import com.library.repository.BookRepository;
import com.library.service.BookService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
 
        BookService service = context.getBean(BookService.class);
        BookRepository repository = context.getBean(BookRepository.class);


        System.out.println("All the books present in the repository:");
        service.addBook("The Wimpy Kid");
        service.addBook("The Secret Seven");
        service.addBook("The Great Gatsby");
        service.addBook("Famous Five");

        service.listAllBooks();

    }
}
