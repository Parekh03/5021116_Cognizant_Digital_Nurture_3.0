package com.example.BookstoreAPI.controller;

import com.example.BookstoreAPI.dto.CustomerDTO;
import com.example.BookstoreAPI.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @PostMapping
    public ResponseEntity<EntityModel<CustomerDTO>> createCustomer(@RequestBody CustomerDTO customerDTO) {
        CustomerDTO createdCustomer = customerService.createCustomer(customerDTO);
        EntityModel<CustomerDTO> resource = EntityModel.of(createdCustomer);
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(CustomerController.class).getCustomerById(createdCustomer.getId())).withSelfRel());
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(CustomerController.class).getAllCustomers()).withRel("customers"));
        return new ResponseEntity<>(resource, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<CustomerDTO>>> getAllCustomers() {
        List<EntityModel<CustomerDTO>> customers = customerService.getAllCustomers().stream()
                .map(customerDTO -> EntityModel.of(customerDTO,
                        WebMvcLinkBuilder.linkTo(methodOn(CustomerController.class).getCustomerById(customerDTO.getId())).withSelfRel(),
                        WebMvcLinkBuilder.linkTo(methodOn(CustomerController.class).getAllCustomers()).withRel("customers")))
                .collect(Collectors.toList());
        CollectionModel<EntityModel<CustomerDTO>> collectionModel = CollectionModel.of(customers);
        collectionModel.add(WebMvcLinkBuilder.linkTo(methodOn(CustomerController.class).getAllCustomers()).withSelfRel());
        return new ResponseEntity<>(collectionModel, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<CustomerDTO>> getCustomerById(@PathVariable int id) {
        CustomerDTO customerDTO = customerService.getCustomerById(id);
        EntityModel<CustomerDTO> resource = EntityModel.of(customerDTO);
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(CustomerController.class).getCustomerById(id)).withSelfRel());
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(CustomerController.class).getAllCustomers()).withRel("customers"));
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(CustomerController.class).updateCustomer(id, customerDTO)).withRel("update"));
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(CustomerController.class).deleteCustomer(id)).withRel("delete"));
        return new ResponseEntity<>(resource, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<CustomerDTO>> updateCustomer(@PathVariable int id, @RequestBody CustomerDTO customerDTO) {
        CustomerDTO updatedCustomer = customerService.updateCustomer(id, customerDTO);
        EntityModel<CustomerDTO> resource = EntityModel.of(updatedCustomer);
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(CustomerController.class).getCustomerById(updatedCustomer.getId())).withSelfRel());
        resource.add(WebMvcLinkBuilder.linkTo(methodOn(CustomerController.class).getAllCustomers()).withRel("customers"));
        return new ResponseEntity<>(resource, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<Void> deleteCustomer(@PathVariable int id) {
        customerService.deleteCustomer(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
