public class Main {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "Alice", 250.75),
            new Order("2", "Bob", 100.50),
            new Order("3", "Charlie", 320.00),
            new Order("4", "David", 150.30),
            new Order("5", "Eve", 275.20)
        };
        
        System.out.println("Order details:\n");
        for(Order o : orders) {
        	System.out.println(o);
        }
        System.out.println();

        // Bubble Sort
        Order[] bubbleSortedOrders = orders.clone();
        System.out.println("Orders before Bubble Sort:");
        for (Order order : bubbleSortedOrders) {
            System.out.println(order);
        }

        BubbleSort.bubbleSort(bubbleSortedOrders);
        System.out.println("\nOrders after Bubble Sort:");
        for (Order order : bubbleSortedOrders) {
            System.out.println(order);
        }

        // Quick Sort
        Order[] quickSortedOrders = orders.clone();
        System.out.println("\nOrders before Quick Sort:");
        for (Order order : quickSortedOrders) {
            System.out.println(order);
        }

        QuickSort.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        System.out.println("\nOrders after Quick Sort:");
        for (Order order : quickSortedOrders) {
            System.out.println(order);
        }
    }
}
