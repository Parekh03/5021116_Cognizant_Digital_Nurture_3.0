public class Main {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        Observer mobileApp = new MobileApp("MobileApp1");
        Observer webApp = new WebApp("WebApp1");

        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        // Changing stock price
        System.out.println("Setting stock price to 100.00");
        stockMarket.setPrice(100.00);

        // Changing stock price again
        System.out.println("Setting stock price to 101.50");
        stockMarket.setPrice(101.50);

        // Removing an observer and changing price again
        stockMarket.removeObserver(mobileApp);
        System.out.println("Setting stock price to 102.75");
        stockMarket.setPrice(102.75);
    }
}
