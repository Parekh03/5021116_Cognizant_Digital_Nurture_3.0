public class Logger {
    // Step 3: Define a private static instance of the Logger class
    private static Logger instance;

    // Step 4: Private constructor to prevent instantiation
    private Logger() {
        // Initialize any resources, if needed
    }

    // Step 5: Public static method to provide the single instance
    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    // Method to log messages
    public void log(String message) {
        System.out.println("Log message: " + message);
    }
}
