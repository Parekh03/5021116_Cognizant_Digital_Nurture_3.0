package com.library.service;

import com.library.repository.BookRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    private BookRepository repo;

    // Constructor for constructor injection
    @Autowired
    public BookService(BookRepository repo) {
        this.repo = repo;
    }

    // Setter method for setter injection
    @Autowired
    public void setRepo(BookRepository repo) {
        this.repo = repo;
    }

    public void printClass() {
        System.out.println("Inside the BookService class.");
    }

    public void addBook(String book) {
        this.repo.save(book);
    }

    public void listAllBooks() {
        List<String> l = repo.findAll();
        for (String book : l) {
            System.out.println(book);
        }
    }
}
