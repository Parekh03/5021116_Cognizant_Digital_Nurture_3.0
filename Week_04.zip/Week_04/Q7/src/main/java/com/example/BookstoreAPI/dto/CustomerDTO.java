package com.example.BookstoreAPI.dto;

public class CustomerDTO {
    private int id;
    private String name;
    private String email;
    private String address;

}
