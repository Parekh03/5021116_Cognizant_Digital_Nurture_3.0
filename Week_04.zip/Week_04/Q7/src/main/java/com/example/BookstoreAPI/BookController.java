package com.example.BookstoreAPI;
import java.util.*;
import java.util.stream.Collectors;

import com.example.BookstoreAPI.dto.BookDTO;
import com.example.BookstoreAPI.mapper.BookMapper;
import com.example.BookstoreAPI.model.Book;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/books")
public class BookController {

    private final List<Book> books = new ArrayList<>();


    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Book createBook(@RequestBody Book book) {
        books.add(book);
        return book;
    }

    @PostMapping
    public BookDTO addBook(@RequestBody BookDTO bookDTO) {
        com.example.BookstoreAPI.model.Book book = BookMapper.INSTANCE.bookDTOToBook(bookDTO);
        books.add(book);
        return BookMapper.INSTANCE.bookToBookDTO(book);
    }

    public List<BookDTO> getAllBooks() {
        return books.stream()
                .map(BookMapper.INSTANCE::bookToBookDTO)
                .toList();
    }

    @PutMapping("/{id}")
    public Book updateBook(@PathVariable int id, @RequestBody Book book) {
        books.set(id, book);
        return book;
    }

    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable int id) {
        books.remove(id);
    }

    @GetMapping("/{id}")
    public BookDTO getBookById(@PathVariable int id) {
        Book book = books.stream()
                .filter(b -> b.getId() == id)
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Book not found"));
        return BookMapper.INSTANCE.bookToBookDTO(book);
    }


    @GetMapping("/search")
    public List<Book> searchBooks(@RequestParam(required = false) String title,
                                  @RequestParam(required = false) String author) {
        return books.stream()
                .filter(book -> (title == null || book.getTitle().contains(title)) &&
                        (author == null || book.getAuthor().contains(author)))
                .collect(Collectors.toList());
    }

    @PostMapping("/customers")
    public Customer createCustomer(@RequestBody Customer customer) {
        // Add logic to save customer
        return customer;
    }

    @PostMapping("/customers/form")
    public Customer createCustomerForm(Customer customer) {
        // Add logic to save customer from form data
        return customer;
    }
    
}
