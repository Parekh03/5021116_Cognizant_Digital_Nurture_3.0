package com.library.service;


import com.library.repository.BookRepository;
import java.util.ArrayList;
import java.util.List;

import java.awt.print.Book;
import java.util.ArrayList;

public class BookService {

    // without dependency injection
    private BookRepository repo = new BookRepository();

    public void printClass(){
        System.out.println("Inside the BookService class.");
    }

    public void addBook(String book){
        this.repo.save(book);
    }

    public void listAllBooks(){
        List<String> l = repo.findAll();
        for(String book : l){
            System.out.println(book);
        }
    }
}
