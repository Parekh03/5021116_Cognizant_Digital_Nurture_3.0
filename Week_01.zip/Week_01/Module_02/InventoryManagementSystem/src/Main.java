import java.util.*;
public class Main {
    private static Inventory inventory = new Inventory();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            showMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over
            switch (choice) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    updateProduct();
                    break;
                case 3:
                    deleteProduct();
                    break;
                case 4:
                    displayProduct();
                    break;
                case 5:
                    inventory.displayProducts();
                    break;
                case 6:
                    System.out.println("Exiting the system.");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void showMenu() {
        System.out.println("\nInventory Management System:");
        System.out.println("1. Add Product");
        System.out.println("2. Update Product");
        System.out.println("3. Delete Product");
        System.out.println("4. Display Product");
        System.out.println("5. Display All Products");
        System.out.println("6. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void addProduct() {
        System.out.print("Enter Product ID: ");
        String productId = scanner.nextLine();
        System.out.print("Enter Product Name: ");
        String productName = scanner.nextLine();
        System.out.print("Enter Quantity: ");
        int quantity = scanner.nextInt();
        System.out.print("Enter Price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Consume newline left-over

        Product product = new Product(productId, productName, quantity, price);
        inventory.addProduct(product);
    }

    private static void updateProduct() {
        System.out.print("Enter Product ID: ");
        String productId = scanner.nextLine();
        System.out.print("Enter new Product Name (or press Enter to skip): ");
        String newName = scanner.nextLine();
        System.out.print("Enter new Quantity (or press Enter to skip): ");
        String quantityInput = scanner.nextLine();
        Integer newQuantity = quantityInput.isEmpty() ? null : Integer.parseInt(quantityInput);
        System.out.print("Enter new Price (or press Enter to skip): ");
        String priceInput = scanner.nextLine();
        Double newPrice = priceInput.isEmpty() ? null : Double.parseDouble(priceInput);

        inventory.updateProduct(productId, newName, newQuantity, newPrice);
    }

    private static void deleteProduct() {
        System.out.print("Enter Product ID: ");
        String productId = scanner.nextLine();
        inventory.deleteProduct(productId);
    }

    private static void displayProduct() {
        System.out.print("Enter Product ID: ");
        String productId = scanner.nextLine();
        Product product = inventory.getProduct(productId);
        if (product != null) {
            System.out.println(product);
        } else {
            System.out.println("Product with ID " + productId + " does not exist.");
        }
    }
}