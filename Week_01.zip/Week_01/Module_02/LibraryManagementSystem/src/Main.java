import java.util.Arrays;

public class Main {
    private Book[] books;
    private int size;

    public Main(int capacity) {
        books = new Book[capacity];
        size = 0;
    }

    // Add a book
    public void addBook(Book book) {
        if (size >= books.length) {
            books = Arrays.copyOf(books, books.length * 2);
        }
        books[size++] = book;
    }

    // Linear search to find a book by title
    public Book linearSearchByTitle(String title) {
        for (int i = 0; i < size; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }

    // Binary search to find a book by title (assuming the list is sorted)
    public Book binarySearchByTitle(String title) {
        int left = 0;
        int right = size - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].getTitle().compareToIgnoreCase(title);
            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    // Method to sort the books by title
    public void sortBooksByTitle() {
        Arrays.sort(books, 0, size, (book1, book2) -> book1.getTitle().compareToIgnoreCase(book2.getTitle()));
    }

    // Method to display all books
    public void displayAllBooks() {
        if (size == 0) {
            System.out.println("No books available in the library.");
            return;
        }
        System.out.println("All Books in the Library:");
        for (int i = 0; i < size; i++) {
            System.out.println(books[i]);
        }
    }

    public static void main(String[] args) {
        Main system = new Main(2);

        // Add books
        system.addBook(new Book("B001", "Harry Potter", "J.K. Rowling"));
        system.addBook(new Book("B002", "The Hobbit", "J.R.R. Tolkien"));
        system.addBook(new Book("B003", "1984", "George Orwell"));

        // Display all books
        system.displayAllBooks();

        // Linear search
        String searchTitle = "The Hobbit";
        Book linearSearchResult = system.linearSearchByTitle(searchTitle);
        System.out.println("\nLinear Search Result for title '" + searchTitle + "':");
        System.out.println(linearSearchResult != null ? linearSearchResult : "Book not found");

        // Sort books by title for binary search
        system.sortBooksByTitle();

        // Binary search
        Book binarySearchResult = system.binarySearchByTitle(searchTitle);
        System.out.println("\nBinary Search Result for title '" + searchTitle + "':");
        System.out.println(binarySearchResult != null ? binarySearchResult : "Book not found");
    }
}
