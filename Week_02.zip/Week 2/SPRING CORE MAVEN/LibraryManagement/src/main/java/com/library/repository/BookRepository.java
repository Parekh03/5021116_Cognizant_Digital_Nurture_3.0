package com.library.repository;
import java.util.ArrayList;
import java.util.List;

public class BookRepository {
//    list to store all the books in the repository
    private List<String> books = new ArrayList<>();

    public void printClass(){
        System.out.println("Inside the BookRepository class");
    }

    public void save(String book){
        books.add(book);
    }

    public List<String> findAll(){
        return new ArrayList<>(books);
    }


}
