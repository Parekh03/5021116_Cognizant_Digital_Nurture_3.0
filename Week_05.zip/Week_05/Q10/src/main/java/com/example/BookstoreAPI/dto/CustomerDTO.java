package com.example.BookstoreAPI.dto;

import org.springframework.hateoas.RepresentationModel;

public class CustomerDTO extends RepresentationModel<CustomerDTO> {
    private int id;
    private String name;
    private String email;
    private String address;
    private int version;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
